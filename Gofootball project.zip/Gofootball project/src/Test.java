import java.util.Scanner;

public class Test{

    public static class Main {

        public static void main(String[] args) {
            System.out.println("/--------------------------------------/");
            System.out.println("WELCOME TO GO FOOTBALL BOOKING SYSTEM  ");
            System.out.println("/--------------------------------------/");
            Scanner scan = new Scanner(System.in);
            String signUp;
            System.out.println(" press on any key to sign up ");
            signUp = scan.nextLine();
            String userName, email, password, location, address;
            System.out.print("userName: ");
            userName = scan.nextLine();
            System.out.print("Email: ");
            email= scan.nextLine();
            System.out.print("Password: ");
            password = scan.nextLine();
            System.out.print("Location: ");
            location = scan.nextLine();
            System.out.print("Address: ");
            address = scan.nextLine();
            SignUp user = new SignUp(userName, email,password,location,address);
            System.out.println("Account is successfully created");
            System.out.println("please sign in below to see more about the Go football");
            user.logIn();



        }
    }
}
