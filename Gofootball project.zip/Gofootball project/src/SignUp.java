/*
* @author: Char Wangkor
* @since: june 8th
*
 */
import java.util.Scanner;

public class SignUp {
    private String userName;
    private String password;
    private String email;
    private String location;
    private String address;

    public SignUp(){
        userName = "";
        email= "";
        password= "";
        location = "";
        address = "";
    }
    public SignUp(String userName, String email, String password, String location ,String address){
        setUserName(userName);
        setEmail(email);
        setPassword(password);
        setLocation(location);
        setLocation(address);
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getUserName() {
        return userName;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getLocation() {
        return location;
    }

    public String getAddress() {
        return address;
    }
    public void logIn() {
        String Email, Password;
        System.out.println("please enter Email amd Password");
        Scanner scan = new Scanner(System.in);
        System.out.print("Email: ");
        Email=scan.nextLine();
        System.out.print("Password: ");
        Password=scan.nextLine();
        if(Email.equals(this.email) && Password.equals(this.password)){
            System.out.println("successfully log in ");
        }else{
            System.out.println("please enter correct email or password");
            logIn();

        }

    }
}